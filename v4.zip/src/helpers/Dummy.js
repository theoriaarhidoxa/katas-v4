import React from 'react';
import './Dummy.scss';

const Dummy = ({pagesLength, currentPage}) => {
    return (
        <div className='overlay'>
            <span />
            {currentPage < pagesLength - 1 && <i>Загружается страница {pagesLength - currentPage}...</i>}
        </div>
    );
};

export default Dummy;
