import './App.scss';
import React, {useState, useEffect, useRef} from "react";
import Dummy from "./helpers/Dummy";
import {animateScroll as scroll} from 'react-scroll'; // https://www.npmjs.com/package/react-scroll https://www.pluralsight.com/guides/scrolling-inside-a-div-in-react

function App() {
    const userName = `catchaser`;
    const [isLoading, setIsLoading] = useState(true);
    const [currentPage, setCurrentPage] = useState(null);
    const reqStr = `https://www.codewars.com/api/v1/users/${userName}/code-challenges/completed?page=${currentPage}`;
    const [pagesLength, setPagesLength] = useState(null);
    const [query, setQuery] = useState('');
    const [list, setList] = useState([]);
    const [savedList, setSavedList] = useState([]);
    const [intersectionPrevent, setIntersectionPrevent] = useState(false);
    const [offset, setOffset] = useState(0);
    const [fetchMore, setFetchMore] = useState(false);

    const container = useRef();
    const bottomBlock = useRef();
    const observer = useRef();
    const scrollerIcon = useRef();

    // ПРИ ДЕПЛОЕ поменять не только /static, но и в chunk.css - background:url(../media/loading-buffering

    const getLastPageId = async () => {
        const res = await fetch(`${reqStr}`);
        const data = await res.json();
        setCurrentPage(data['totalPages'] - 1);
    };

    const fetchData = async () => {
        if (typeof currentPage === 'number' && currentPage >= 0) {
            setIsLoading(true);
            const res = await fetch(`${reqStr}`);
            const katas = await res.json();
            if (!pagesLength) {
                setPagesLength(katas['totalPages']);
            }

            if (katas.data.length < 22) {
                setFetchMore(true);
            }

            setTimeout(() => {
                setIsLoading(false);
                setList([...list, ...katas.data.reverse()]);
                setSavedList([...savedList, ...katas.data]);
            }, 1000);
        }
    };

    const handleInputQuery = e => {
        if (!e.target.value.length) {
            setList(savedList);
        }
        topScroller();
        setQuery(e.target.value);
        setIntersectionPrevent(e.target.value.length > 0);
        setList(savedList.filter(el => el.name.toLowerCase().startsWith(e.target.value.toLowerCase())));
    };

    const topScroller = () => {
        scroll.scrollToTop({
            duration: 1000,
            delay: 0,
            smooth: true,
            offset: 0, // Scrolls to element + 0 pixels down the page
        });
    };

    const keyPressHandler = e => {
        if (!query) {
            return;
        }
        const {keyCode} = e;
        if (keyCode === 27) {
            setQuery('');
            setList(savedList);
            setIntersectionPrevent(e.target.value?.length > 0);
            scrollerIcon.current.classList.remove('invisible');
        }
    };


    useEffect(() => {
        getLastPageId().then();
    }, []);

    useEffect(() => {
        if (intersectionPrevent) {
            return;
        }
        fetchData().then();
    }, [currentPage]);

    useEffect(() => {
        if (fetchMore && !list.length) {
            setTimeout(() => {
                setCurrentPage(prev => prev - 1);
            }, 2000);

        }
    }, [fetchMore]);

    useEffect(() => {
        const callback = (entries) => {
            if (entries[0].isIntersecting) {
                setCurrentPage(prev => prev - 1);
            }
        };
        observer.current = new IntersectionObserver(callback);
        observer.current.observe(bottomBlock.current);
    }, []);

    useEffect(() => {
        window.addEventListener('keydown', keyPressHandler);
        return () => window.removeEventListener('keydown', keyPressHandler);
    }, [query]);


    useEffect(() => {
        // https://www.npmjs.com/package/@react-hook/window-scroll alternative?
        window.onscroll = () => {
            setOffset(window.pageYOffset);
        }
    }, [offset]);

    useEffect(() => {
        if (scrollerIcon.current) {
            container.current.offsetHeight < window.screen.height ? scrollerIcon.current.classList.add('invisible') : scrollerIcon.current.classList.remove('invisible');
        }
    }, [query]);


    return (
        <>
            {isLoading && <Dummy currentPage={currentPage} pagesLength={pagesLength} />}
            <div className='wrapper' ref={container}>
                {(!isLoading) &&
                <p>Небольшая вариация на основе предыдущей версии - ката отсортированы в&nbsp;хронологическом порядке и добавлена очистка поля ввода по Escape.</p>}

                <p className={intersectionPrevent ? 'wrapper__alert danger visible' : 'wrapper__alert'}>Динамическая
                    подгрузка контента не работает одновременно с поиском.<br/> Перед проматыванием страницы вниз
                    необходимо очистить поле ввода.</p>

                {!isLoading && <input value={query}
                                      className={offset > 100 && !intersectionPrevent ? 'wrapper__query floating' : 'wrapper__query'}
                                      placeholder='Поиск по названию' type='text'
                                      onChange={handleInputQuery}/>}

                {list.length ? <div className='listWrapper'>
                    {list.map((el, i) => {
                        const {id, completedAt, name} = el;
                        const parsedDate = completedAt.substring(0, completedAt.indexOf('T')).split('-').reverse().join('.');
                        return (
                            <div className='listWrapper__item' key={id}>
                                <span>{i + 1}. {name}</span>
                                <small>{parsedDate}</small>
                            </div>
                        )
                    })}
                </div> : !isLoading ? 'Поиск не дал результатов.' : null}

                <div ref={bottomBlock}
                     className={intersectionPrevent ? 'wrapper__bottomBlock inactive' : 'wrapper__bottomBlock'}/>
                {currentPage < 0 && list.length > 0 &&
                <p className='wrapper__alert success visible'>Все элементы списка загружены.</p>}
                {!isLoading && <span ref={scrollerIcon} className='scrollTop' onClick={topScroller}>scroll</span>}
            </div>
        </>
    );
}

export default App;
